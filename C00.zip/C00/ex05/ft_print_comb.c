#include <unistd.h>

void ft_print_comb()
{
  write(1,1,1);
}

